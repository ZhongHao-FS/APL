//
//  Second ViewController.swift
//  Exercise06
//
//  Created by Hao Zhong on 5/16/21.
//Part2: Second ViewController

import UIKit

class Second_ViewController: UIViewController {

    @IBOutlet weak var colorView: UIView!
    @IBOutlet weak var redSlider: UISlider!
    @IBOutlet weak var blueSlider: UISlider!
    @IBOutlet weak var greenSlider: UISlider!
    
    var redValue: CGFloat?
    var blueValue: CGFloat?
    var greenValue: CGFloat?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        redSlider.value = Float(redValue!)
        blueSlider.value = Float(blueValue!)
        greenSlider.value = Float(greenValue!)
        refreshColor()
    }
    
    func refreshColor() {
        colorView.backgroundColor = UIColor (red: CGFloat(redSlider.value), green: CGFloat(greenSlider.value), blue: CGFloat(blueSlider.value), alpha: 1.0)
    }

    @IBAction func redChanged(_ sender: UISlider) {
        refreshColor()
    }
    
    @IBAction func blueChanged(_ sender: UISlider) {
        refreshColor()
    }
    
    @IBAction func greenChanged(_ sender: UISlider) {
        refreshColor()
    }
    
    @IBAction func randomValues(_ sender: UIButton) {
        redSlider.value = Float.random(in: 0.0...1.0)
        blueSlider.value = Float.random(in: 0.0...1.0)
        greenSlider.value = Float.random(in: 0.0...1.0)
        refreshColor()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
