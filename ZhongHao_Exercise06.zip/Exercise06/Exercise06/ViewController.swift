//
//  ViewController.swift
//  Exercise06
//
//  Created by Hao Zhong on 5/16/21.
//Part1: First ViewController

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var colorView: UIView!
    @IBOutlet weak var red: UILabel!
    @IBOutlet weak var blue: UILabel!
    @IBOutlet weak var green: UILabel!
    
    var redPart: CGFloat = 0.0
    var bluePart: CGFloat = 0.0
    var greenPart: CGFloat = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        updateData()
    }
    func updateData() {
        colorView.backgroundColor = UIColor (red: redPart, green: greenPart, blue: bluePart, alpha: 1.0)
        
        red.text = "Red: \(redPart)"
        blue.text = "Blue: \(bluePart)"
        green.text = "Green: \(greenPart)"
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destination = segue.destination as! Second_ViewController
        destination.redValue = redPart
        destination.blueValue = bluePart
        destination.greenValue = greenPart
    }
    
    @IBAction func unwindToRoot(segue: UIStoryboardSegue) {
        let source = segue.source as! Second_ViewController
        redPart = CGFloat(source.redSlider.value)
        bluePart = CGFloat(source.blueSlider.value)
        greenPart = CGFloat(source.greenSlider.value)
        updateData()
    }
}

