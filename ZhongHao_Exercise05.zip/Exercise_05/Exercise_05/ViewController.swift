//
//  ViewController.swift
//  Exercise_05
//
//  Created by Hao Zhong on 5/15/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var number1: UITextField!
    @IBOutlet weak var number2: UITextField!
    @IBOutlet weak var result: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func add(_ sender: Any) {
        if let num1 = Int(number1.text ?? "0"), let num2 = Int(number2.text ?? "0") {
            result.text = "= " + String(num1 + num2)
        } else {
            result.text = "Please enter numeric values"
        }
    }
    
    @IBAction func substract(_ sender: Any) {
        if let num1 = Int(number1.text ?? "0"), let num2 = Int(number2.text ?? "0") {
            result.text = "= " + String(num1 - num2)
        } else {
            result.text = "Please enter numeric values"
        }
    }
    
    @IBAction func multiply(_ sender: Any) {
        if let num1 = Int(number1.text ?? "1"), let num2 = Int(number2.text ?? "1") {
            result.text = "= " + String(num1 * num2)
        } else {
            result.text = "Please enter numeric values"
        }
    }
    
    @IBAction func divide(_ sender: Any) {
        if let num1 = Int(number1.text ?? "1"), let num2 = Int(number2.text ?? "1") {
            if num2 == 0 {
                result.text = "Number1 cannot be divided by 0"
            } else {
                if num1 % num2 == 0 {
                    result.text = "= " + String(num1 / num2)
                } else {
                    result.text = "= \(Decimal(num1) / Decimal(num2))"
                }
            }
        } else {
            result.text = "Please enter numeric values"
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
}

