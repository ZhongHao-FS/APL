//
//  Continent_ViewController.swift
//  Week2Synthesis
//
//  Created by Hao Zhong on 5/16/21.
//Part3: Second ViewController

import UIKit

class Continent_ViewController: UIViewController {

    @IBOutlet weak var contiName: UILabel!
    @IBOutlet weak var contiDetail: UITextView!
    
    var continentName: String?
    var contiDictionary: [String: Int]?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        contiName.text = continentName
        update()
    }
    
    func update() {
        contiDetail.text = reportTotal()
        reportCountries()
    }
    
    func reportTotal() -> String {
        var totalC = 0
        var totalP = 0
        
        for country in contiDictionary! {
            totalC += 1
            totalP += country.value
        }
        
        return "\(continentName!) has \(totalC) countries, with a total population of \(totalP)."
    }
    
    func reportCountries() {
        for country in contiDictionary! {
            contiDetail.text += "\n\(country.key) has a population of \(country.value) people."
        }
    }
    
    @IBAction func unwindToParent(segue: UIStoryboardSegue) {
        let source = segue.source as! NewCountry_ViewController
        contiDictionary![source.newName] = Int(source.newPop)
        update()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
