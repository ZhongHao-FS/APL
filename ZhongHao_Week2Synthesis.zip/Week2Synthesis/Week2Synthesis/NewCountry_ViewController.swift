//
//  NewCountry_ViewController.swift
//  Week2Synthesis
//
//  Created by Hao Zhong on 5/16/21.
//Part4: Third ViewController

import UIKit

class NewCountry_ViewController: UIViewController {

    @IBOutlet weak var newContryName: UITextField!
    @IBOutlet weak var newContryPop: UITextField!
    
    var newName = ""
    var newPop = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func cancel(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        newName = newContryName.text ?? ""
        newPop = Int(newContryPop.text ?? "") ?? 0
        if newContryName.text == "" || newContryPop.text == "" {
            let alert = UIAlertController(title: "Warning", message: "Please fill in both fields", preferredStyle: UIAlertController.Style.alert)
            let okButton = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil)
            alert.addAction(okButton)
            present(alert, animated: true, completion: nil)
            
            return false
        } else {
            return true
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
