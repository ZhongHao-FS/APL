//
//  ViewController.swift
//  Week2Synthesis
//
//  Created by Hao Zhong on 5/16/21.
//Part1: Data Model

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var sumUp: UITextView!
    
    var world: [String: [String: Int]] = [:]
    var continentPath = ""
    
    //Part2: First ViewController
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        world["Africa"] = [:]
        world["Asia"] = [:]
        world["Australia"] = [:]
        world["Europe"] = [:]
        world["North America"] = [:]
        world["South America"] = [:]
        updateTotal()
    }

    func updateTotal() {
        var totalC = 0
        var totalP = 0
        
        for continent in world {
            for country in continent.value {
                totalC += 1
                totalP += country.value
            }
        }
        
        sumUp.text = "There are \(totalC) countries in the world with a total population of \(totalP)."
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destination = segue.destination as! Continent_ViewController
        destination.continentName = self.continentPath
        destination.contiDictionary = self.world[continentPath]
    }
    
    @IBAction func Africa(_ sender: UIButton) {
        self.continentPath = "Africa"
        performSegue(withIdentifier: "toSecond", sender: self)
    }
    
    @IBAction func Asia(_ sender: UIButton) {
        self.continentPath = "Asia"
        performSegue(withIdentifier: "toSecond", sender: self)
    }
    
    @IBAction func Australia(_ sender: UIButton) {
        self.continentPath = "Australia"
        performSegue(withIdentifier: "toSecond", sender: self)
    }
    
    @IBAction func Europe(_ sender: UIButton) {
        self.continentPath = "Europe"
        performSegue(withIdentifier: "toSecond", sender: self)
    }
    
    @IBAction func northAmerica(_ sender: UIButton) {
        self.continentPath = "North America"
        performSegue(withIdentifier: "toSecond", sender: self)
    }
    
    @IBAction func southAmerica(_ sender: UIButton) {
        self.continentPath = "South America"
        performSegue(withIdentifier: "toSecond", sender: self)
    }
    
    @IBAction func unwindToRoot(segue: UIStoryboardSegue) {
        let source = segue.source as! Continent_ViewController
        world[source.continentName!] = source.contiDictionary
        updateTotal()
    }
}

