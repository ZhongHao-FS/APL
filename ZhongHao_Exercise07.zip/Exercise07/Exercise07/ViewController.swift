//
//  ViewController.swift
//  Exercise07
//
//  Created by Hao Zhong on 5/20/21.
//Part1: First ViewController

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var lastName: UITextField!
    @IBOutlet weak var gender: UITextField!
    @IBOutlet weak var age: UITextField!
    @IBOutlet weak var eyeColor: UITextField!
    @IBOutlet weak var occupation: UITextField!
    @IBOutlet weak var reduced: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case self.firstName:
            self.lastName.becomeFirstResponder()
        case self.lastName:
            self.gender.becomeFirstResponder()
        case self.gender:
            self.age.becomeFirstResponder()
        case self.age:
            self.eyeColor.becomeFirstResponder()
        case self.eyeColor:
            self.occupation.becomeFirstResponder()
        default:
            self.view.endEditing(true)
        }
        
        return true
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if firstName.text == "" || lastName.text == "" || gender.text == "" || age.text == "" || eyeColor.text == "" || occupation.text == "" {
            let alert = UIAlertController(title: "Warning", message: "All text fields are required!", preferredStyle: UIAlertController.Style.alert)
            let okButton = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil)
            alert.addAction(okButton)
            present(alert, animated: true, completion: nil)
            
            return false
        }
        return true
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destination = segue.destination as! Second_ViewController
        if firstName.text != nil, lastName.text != nil, gender.text != nil, age.text != nil, eyeColor.text != nil, occupation.text != nil {
            destination.textInput = []
            destination.textInput.append("First Name: " + firstName.text!)
            destination.textInput.append("Last Name: " + lastName.text!)
            destination.textInput.append("Gender: " + gender.text!)
            destination.textInput.append("Age: " + age.text!)
            destination.textInput.append("Eye Color: " + eyeColor.text!)
            destination.textInput.append("Occupation: " + occupation.text!)
        }
    }
    
    @IBAction func unwindToRoot(segue: UIStoryboardSegue) {
        let source = segue.source as! Second_ViewController
        reduced.text = source.textInput.reduce("", {x, y in x + "\n" + y})
    }
}

