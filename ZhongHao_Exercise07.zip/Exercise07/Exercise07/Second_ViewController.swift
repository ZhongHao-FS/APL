//
//  Second_ViewController.swift
//  Exercise07
//
//  Created by Hao Zhong on 5/20/21.
//Part2: Second ViewController

import UIKit

class Second_ViewController: UIViewController {

    @IBOutlet weak var firstName: UILabel!
    @IBOutlet weak var lastName: UILabel!
    @IBOutlet weak var gender: UILabel!
    @IBOutlet weak var age: UILabel!
    @IBOutlet weak var eyeColor: UILabel!
    @IBOutlet weak var occupation: UILabel!
    
    var textInput: [String] = ["First Name: ", "Last Name: ", "Gender: ", "Age: ", "Eye Color: ", "Occupation"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.firstName.text = textInput[0]
        self.lastName.text = textInput[1]
        self.gender.text = textInput[2]
        self.age.text = textInput[3]
        self.eyeColor.text = textInput[4]
        self.occupation.text = textInput[5]
    }
    
    @IBAction func cancel(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
