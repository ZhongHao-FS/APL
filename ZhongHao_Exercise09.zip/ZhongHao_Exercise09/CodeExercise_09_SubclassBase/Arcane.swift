//
//  Arcane.swift
//  CodeExercise_09_SubclassBase
//
//  Created by Hao Zhong on 5/23/21.
//  Copyright © 2021 Hao Zhong. All rights reserved.
//Part2: Optional Struct

import Foundation

struct Arcane {
    var arcanePower: Int
    var arcaneType: String
    
    init() {
        arcanePower = 10
        arcaneType = "Fire"
    }
    
    init(power: Int, type: String) {
        arcanePower = power
        arcaneType = type
    }
}
