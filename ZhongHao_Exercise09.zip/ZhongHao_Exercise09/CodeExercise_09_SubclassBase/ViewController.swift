//
//  ViewController.swift
//  CodeExercise_09_SubclassBase
//
//  Created by Scott Caruso.
//  Copyright © 2019 Scott Caruso. All rights reserved.
//Part3: User Interface

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var characterName: UILabel!
    @IBOutlet weak var characterLevel: UILabel!
    @IBOutlet weak var characterHP: UILabel!
    @IBOutlet weak var characterMP: UILabel!
    @IBOutlet weak var characterStrength: UILabel!
    @IBOutlet weak var characterDefense: UILabel!
    @IBOutlet weak var characterXP: UILabel!
    @IBOutlet weak var magicAttack: UILabel!
    @IBOutlet weak var mageIntelligence: UILabel!
    @IBOutlet weak var arcanePower: UILabel!
    @IBOutlet weak var arcaneType: UILabel!
    @IBOutlet weak var readyToLevel: UILabel!
    @IBOutlet weak var xpRequired: UILabel!
    
    var character = Mage()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    //Using the viewWillAppear method so that we can easily update the UI elements when coming back from the CharacterObjectEditor controller.
    override func viewWillAppear(_ animated: Bool) {
        updateLabels()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //This function calls the levelUp method, and also makes sure to tell the user if the levelUp cannot be run for some reason.
    @IBAction func levelUp() {
        let canLevel = character.levelUp()
        if !canLevel {
            let alert = UIAlertController(title: "Can't Level", message: "The character doesn't have enough XP to level up!", preferredStyle: .alert)
            let okButton = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alert.addAction(okButton)
            present(alert, animated: true, completion: nil)
        } else {
            updateLabels()
        }
    }
    
    //Simple function to call the defeatMonster() method on the character class, increasing the character's XP.
    @IBAction func defeatMonster() {
        character.defeatMonster()
        updateLabels()
    }
    
    //This function updates the data in the text fields on demand.
    func updateLabels() {
        characterName.text = character.name
        characterLevel.text = String(character.level)
        characterHP.text = String(character.stats.hitPoints)
        characterMP.text = String(character.stats.magicPoints)
        characterStrength.text = String(character.stats.strength)
        characterDefense.text = String(character.stats.defense)
        characterXP.text = String(character.stats.experiencePoints)
        
        magicAttack.text = String(character.magicAttack)
        mageIntelligence.text = String(character.intelligence)
        
        if let power = character.arcane?.arcanePower {
            arcanePower.text = String(power)
        } else {
            arcanePower.text = "No Arcane"
        }
        if let type = character.arcane?.arcaneType {
            arcaneType.text = type
        } else {
            arcaneType.text = "No Arcane"
        }
        
        readyToLevel.text = String(character.readyToLevelUp)
        xpRequired.text = String(character.experiencePointsToLevelUp)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let characterObjectEditor = segue.destination as? CharacterObjectEditor {
            characterObjectEditor.character = character
        }
    }
    
    @IBAction func unwindToRoot(segue: UIStoryboardSegue) {
        let source = segue.source as! CharacterObjectEditor
        self.character = source.character
        updateLabels()
    }
}

