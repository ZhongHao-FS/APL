//
//  Mage.swift
//  CodeExercise_09_SubclassBase
//
//  Created by Hao Zhong on 5/23/21.
//  Copyright © 2021 Hao Zhong. All rights reserved.
//Part1: Subclass Your Base Class

import Foundation

class Mage: GameCharacter {
    var magicAttack: Int
    var intelligence: Int
    var arcane: Arcane?
    
    override func levelUp() -> Bool {
        if self.readyToLevelUp {
            self.magicAttack += Int.random(in: 1...11)
            self.intelligence += Int.random(in: 1...11)
            if let _ = self.arcane?.arcanePower {
                self.arcane?.arcanePower += Int.random(in: 1...11)
            }
        }
        return super.levelUp()
    }
    
    override init() {
        magicAttack = 3
        intelligence = 5
        let option = Bool.random()
        if option {
            arcane = Arcane()
        }
        super.init()
    }
    
    init(name: String, level: Int, hitPoints: Int, magicPoints: Int, strength: Int, defense: Int, experiencePoints: Int, magicAttack: Int, intelligence: Int, arcPower: Int?, arcType: String?) {
        self.magicAttack = magicAttack
        self.intelligence = intelligence
        if let p = arcPower, let t = arcType {
            self.arcane = Arcane(power: p, type: t)
        }
        super.init(name: name, level: level, hitPoints: hitPoints, magicPoints: magicAttack, strength: strength, defense: defense, experiencePoints: experiencePoints)
    }
}
