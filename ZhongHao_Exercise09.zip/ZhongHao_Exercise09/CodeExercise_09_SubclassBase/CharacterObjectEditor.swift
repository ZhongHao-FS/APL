//
//  CharacterObjectEditor.swift
//  CodeExercise_09_SubclassBase
//
//  Created by Scott Caruso.
//  Copyright © 2019 Scott Caruso. All rights reserved.
//Part3: User Interface

import UIKit

class CharacterObjectEditor: UIViewController {

    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var levelTextField: UITextField!
    @IBOutlet weak var hpTextField: UITextField!
    @IBOutlet weak var mpTextField: UITextField!
    @IBOutlet weak var strTextField: UITextField!
    @IBOutlet weak var defTextField: UITextField!
    @IBOutlet weak var xpTextField: UITextField!
    @IBOutlet weak var magicAttack: UITextField!
    @IBOutlet weak var intelligenceField: UITextField!
    @IBOutlet weak var arcPower: UITextField!
    @IBOutlet weak var arcType: UITextField!
    
    var character: Mage! = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let character = character {
            nameTextField.text = character.name
            levelTextField.text = String(character.level)
            hpTextField.text = String(character.stats.hitPoints)
            mpTextField.text = String(character.stats.magicPoints)
            strTextField.text = String(character.stats.strength)
            defTextField.text = String(character.stats.defense)
            xpTextField.text = String(character.stats.experiencePoints)
            magicAttack.text = String(character.magicAttack)
            intelligenceField.text = String(character.intelligence)
            if let arcane = character.arcane {
                arcPower.text = String(arcane.arcanePower)
                arcType.text = arcane.arcaneType
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        return saveChanges()
    }
    
    func saveChanges() -> Bool {
        if (nameTextField.text?.isEmpty)! || (levelTextField.text?.isEmpty)! || (hpTextField.text?.isEmpty)! || (mpTextField.text?.isEmpty)! || (strTextField.text?.isEmpty)! || (defTextField.text?.isEmpty)! || (xpTextField.text?.isEmpty)! || (magicAttack.text?.isEmpty)! || (intelligenceField.text?.isEmpty)! {
            displayError()
            return false
        } else {
            if let _ = character, let name = nameTextField.text, let level = Int(levelTextField.text!), let hp = Int(hpTextField.text!), let mp = Int(mpTextField.text!), let strength = Int(strTextField.text!), let defense = Int(defTextField.text!), let xp = Int(xpTextField.text!), let ma = Int(magicAttack.text!), let intel = Int(intelligenceField.text!) {
                character.name = name
                character.level = level
                character.stats.hitPoints = hp
                character.stats.magicPoints = mp
                character.stats.strength = strength
                character.stats.defense = defense
                character.stats.experiencePoints = xp
                character.magicAttack = ma
                character.intelligence = intel
                if let power = Int(arcPower.text!), let type = arcType.text {
                    character.arcane = Arcane(power: power, type: type)
                } else {
                    character.arcane = nil
                }
                return true
            } else {
                displayError()
                return false
            }
        }
    }
    
    //This function simply dismisses the ViewController without commiting any changes.
    @IBAction func dismissView() {
        dismiss(animated: true, completion: nil)
    }
    
    func displayError() {
        let alert = UIAlertController(title: "Invalid Input", message: "Please ensure all required fields are filled, and all number fields have whole numbers in them!", preferredStyle: .alert)
        let okButton = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alert.addAction(okButton)
        present(alert, animated: true, completion: nil)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
}
