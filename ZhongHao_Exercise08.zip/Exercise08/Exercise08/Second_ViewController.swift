//
//  Second_ViewController.swift
//  Exercise08
//
//  Created by Hao Zhong on 5/22/21.
//Part3: Second ViewController

import UIKit

class Second_ViewController: UIViewController {

    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var level: UITextField!
    @IBOutlet weak var alive: UISwitch!
    @IBOutlet weak var hp: UISlider!
    @IBOutlet weak var xp: UITextField!
    
    var character: Player! = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.name.text = character.name
        self.level.text = "\(character.level)"
        self.alive.isOn = character.alive
        self.hp.maximumValue = Float(character.maxHP)
        self.hp.value = Float(character.hp)
        self.xp.text = "\(character.xp)"
    }
    
    @IBAction func cancel(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if self.name.text == "" || Int(self.level.text ?? "") == nil || Int(self.xp.text ?? "") == nil {
            let alert = UIAlertController(title: "Warning", message: "Please fill in valid values in all fields", preferredStyle: UIAlertController.Style.alert)
            let okButton = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil)
            alert.addAction(okButton)
            present(alert, animated: true, completion: nil)
            
            return false
        } else {
            character.name = self.name.text!
            character.level = Int(self.level.text!)!
            character.alive = self.alive.isOn
            character.hp = Int(self.hp.value)
            character.xp = Int(self.xp.text!)!
            
            return true
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
