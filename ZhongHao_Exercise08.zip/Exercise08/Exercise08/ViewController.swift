//
//  ViewController.swift
//  Exercise08
//
//  Created by Hao Zhong on 5/21/21.
//Part2: First ViewController

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var level: UILabel!
    @IBOutlet weak var alive: UILabel!
    @IBOutlet weak var hp: UILabel!
    @IBOutlet weak var xp: UILabel!
    @IBOutlet weak var maxHP: UILabel!
    @IBOutlet weak var levelUPXP: UILabel!
    
    var me = Player()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        refresh()
    }

    func refresh() {
        name.text = me.name
        level.text = "\(me.level)"
        if me.alive == true {
            alive.text = "Alive"
        } else {
            alive.text = "Dead"
        }
        hp.text = "\(me.hp)"
        xp.text = "\(me.xp)"
        maxHP.text = "\(me.maxHP)"
        levelUPXP.text = "\(me.levelUpXP)"
    }
    
    @IBAction func hunt(_ sender: UIButton) {
        me.huntMonster()
        refresh()
    }
    
    @IBAction func levelUP(_ sender: UIButton) {
        me.levelUP()
        refresh()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destination = segue.destination as! Second_ViewController
        destination.character = self.me
    }
    
    @IBAction func unwindToRoot(segue: UIStoryboardSegue) {
        let source = segue.source as! Second_ViewController
        self.me = source.character
        refresh()
    }
}

