//
//  Player.swift
//  Exercise08
//
//  Created by Hao Zhong on 5/21/21.
//Part1: Custom Base Class

import Foundation
class Player {
    // Stored properties
    var name: String
    var level: Int
    var alive: Bool
    var hp: Int
    var xp: Int
    
    // Computed properties
    var maxHP: Int {
        get {
            return level * 10 + 100
        }
    }
    
    var levelUpXP: Int {
        get {
            return level * 10
        }
    }
    
    // Instance Methods
    func huntMonster() {
        let damage = Int.random(in: 1...20)
        hp -= damage
        xp += damage * 2
        if hp <= 0 {
            alive = false
            hp = 0
            print("Oh no, the player was just killed!")
        } else {
            print("The player has hunted a monster!")
        }
    }
    
    func levelUP() {
        if xp >= levelUpXP {
            xp -= levelUpXP
            level += 1
            hp = maxHP
            print("The player has leveled up!")
        } else {
            print("Not enough xp to level up!")
        }
    }
    
    // Initializers
    init() {
        name = "Winnerknight"
        level = 1
        alive = true
        hp = 110
        xp = 0
    }
    
    init(character: String, lv: Int, alive: Bool, health: Int, experience: Int) {
        self.name = character
        self.level = lv
        self.alive = alive
        self.hp = health
        self.xp = experience
    }
}
